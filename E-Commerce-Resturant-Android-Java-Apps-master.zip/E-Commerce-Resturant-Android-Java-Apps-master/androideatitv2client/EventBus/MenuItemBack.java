package com.ds.androideatitv2client.EventBus;

public class MenuItemBack {
    public MenuItemBack() {
    }
}
