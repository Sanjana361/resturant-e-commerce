package com.ds.androideatitv2client.Callback;

import android.view.View;

public interface IRecyclerClickListener {
    void onItemClickListener(View view, int pos);
}
