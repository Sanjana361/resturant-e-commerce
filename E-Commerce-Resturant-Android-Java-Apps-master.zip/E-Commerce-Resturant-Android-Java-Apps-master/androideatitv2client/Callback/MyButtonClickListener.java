package com.ds.androideatitv2client.Callback;

public interface MyButtonClickListener {
    void onClick(int pos);

}
