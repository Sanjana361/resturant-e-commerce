package com.ds.androideatitv2server.Model;

public class FCMResult {
    private String message_id;

    public FCMResult() {
    }

    public String getMessage_id() {
        return message_id;
    }

    public void setMessage_id(String message_id) {
        this.message_id = message_id;
    }
}
