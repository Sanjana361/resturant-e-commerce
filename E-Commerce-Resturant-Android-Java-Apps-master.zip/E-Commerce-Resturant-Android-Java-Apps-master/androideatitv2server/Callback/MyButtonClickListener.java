package com.ds.androideatitv2server.Callback;

public interface MyButtonClickListener {
    void onClick(int pos);
}
