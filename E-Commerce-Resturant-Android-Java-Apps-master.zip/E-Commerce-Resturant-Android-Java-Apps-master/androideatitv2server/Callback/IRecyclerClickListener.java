package com.ds.androideatitv2server.Callback;

import android.view.View;

public interface IRecyclerClickListener {
    void onItemClickListener(View view, int pos);
}
