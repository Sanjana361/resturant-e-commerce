package com.ds.androideatitv2shipper.Model.EventBus;

public class UpdateShippingOrderEvent {
}
